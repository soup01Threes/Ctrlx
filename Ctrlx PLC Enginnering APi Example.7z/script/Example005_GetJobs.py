import requests

#The base URL that you can find in the API Reference
CTRLX_URL_Basic='http://localhost:9002/plc/engineering/api/v2'

def printData(r):
  #Get Status Code
  print('Status Code=%s'%(r.status_code))
  #Get json Data
  data=r.json()
  #Output
  print('----Data----')
  for k,v in data.items():
      print('key:%s , value:%s'%(k,v))

#Send devices
r=requests.get(CTRLX_URL_Basic+'%s'%('/product/info'))
printData(r)

r=requests.get(CTRLX_URL_Basic+'%s'%('/projects/current'))
printData(r)

