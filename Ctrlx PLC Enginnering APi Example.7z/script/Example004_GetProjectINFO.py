import requests

#The base URL that you can find in the API Reference
CTRLX_URL_Basic='http://localhost:9002/plc/engineering/api/v2'

#Post Content
postData='''
{
  "name": "%s",
  "elementType": "GVL",
  "elementProperties": {
    "build": {
      "excludeFromBuild": false,
      "external": false,
      "enableSystemCall": false,
      "linkAlways": false,
      "compilerDefines": ""
    }
  },
  "declaration": "{attribute 'qualified_only'}\nVAR_GLOBAL\nr32Real:array[0..31]of real;\nEND_VAR"
}
'''%('GVLFromAPI')

def printData(r):
  #Get Status Code
  print('Status Code=%s'%(r.status_code))
  #Get json Data
  data=r.json()
  #Output
  print('----Data----')
  for k,v in data.items():
      print('key:%s , value:%s'%(k,v))

#Send devices
r=requests.get(CTRLX_URL_Basic+'%s'%('/product/info'))
printData(r)

r=requests.get(CTRLX_URL_Basic+'%s'%('/projects/current'))
printData(r)

