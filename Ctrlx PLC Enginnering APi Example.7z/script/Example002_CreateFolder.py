import requests

#The base URL that you can find in the API Reference
CTRLX_URL_Basic='http://localhost:9002/plc/engineering/api/v2'

#Post Content
postData='''
{
  "name": "%s",
  "elementType": "Folder",
  "elementProperties": {
    "build": {
      "excludeFromBuild": false,
      "external": false,
      "enableSystemCall": false,
      "linkAlways": false,
      "compilerDefines": ""
    },
    "documentation": "Folder Documentation @123"
  }
}
'''%('FolderFromAPI')

#Send devices
r=requests.post(CTRLX_URL_Basic+'%s'%('/devices'),data=postData)

#Get Status Code
print('Status Code=%s'%(r.status_code))

#Get json Data
data=r.json()

#Output
print('----Data----')
for k,v in data.items():
    print('key:%s , value:%s'%(k,v))