import requests


CTRLX_URL_Basic='http://localhost:9002/plc/engineering/api/v2'

r=requests.get(CTRLX_URL_Basic+'%s'%('/devices'))

print(r.status_code)
print(r.json())

GVL_request='''
{
  "name": "MyFolder",
  "elementType": "Folder",
  "elementProperties": {
    "build": {
      "excludeFromBuild": false,
      "external": false,
      "enableSystemCall": false,
      "linkAlways": false,
      "compilerDefines": ""
    },
    "documentation": "Folder Documentation @123"
  }
}
'''

r=requests.get(url=CTRLX_URL_Basic+'%s'%('/devices/VirtualControl_1'))
print(r.status_code)
print(r.json)
